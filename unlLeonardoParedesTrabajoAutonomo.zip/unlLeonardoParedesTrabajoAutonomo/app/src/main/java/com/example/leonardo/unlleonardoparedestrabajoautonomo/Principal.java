package com.example.leonardo.unlleonardoparedestrabajoautonomo;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;

public class Principal extends AppCompatActivity {
    TextView resultado, resultado1;
    EditText gradosF, gradosC;
    Button boton;
    public static final String TAG= Principal.class.getSimpleName();

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_principal);
        resultado=(TextView) findViewById(R.id.lblver);
        resultado1=(TextView) findViewById(R.id.lblver1);
        gradosF=(EditText) findViewById(R.id.txtgrados);
        gradosC=(EditText) findViewById(R.id.txtgrdos2);
        boton=(Button) findViewById(R.id.btnresultado);
        boton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                double n= Double.parseDouble(gradosF.getText().toString());
                double n1=Double.parseDouble(gradosC.getText().toString());
                double r= (n-32)/1.8;
                double r1=(n1*1.8)+32;
                resultado.setText("" + r+ "ºC ");
                resultado1.setText(" "+r1+" ºF");
            }
        });
        Log.w(TAG,"Leonardo Vicenete Paredes Rivas");
    }
}
